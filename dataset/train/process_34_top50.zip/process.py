# import libraries here
import matplotlib
import matplotlib.pyplot as plt
import numpy as bb8
import cv2
from scipy import signal


def count_blood_cells(image_path):
    """
    Procedura prima putanju do fotografije i vraca broj crvenih krvnih zrnaca, belih krvnih zrnaca i
    informaciju da li pacijent ima leukemiju ili ne, na osnovu odnosa broja krvnih zrnaca

    Ova procedura se poziva automatski iz main procedure i taj deo kod nije potrebno menjati niti implementirati.

    :param image_path: <String> Putanja do ulazne fotografije.
    :return: <int>  Broj prebrojanih crvenih krvnih zrnaca,
             <int> broj prebrojanih belih krvnih zrnaca,
             <bool> da li pacijent ima leukemniju (True ili False)
    """
    # TODO - Prebrojati crvena i bela krvna zrnca i vratiti njihov broj kao povratnu vrednost ove procedure

    # TODO - Odrediti da li na osnovu broja krvnih zrnaca pacijent ima leukemiju i vratiti True/False kao povratnu vrednost ove procedure
    all_cells_count = count_all(image_path)
    white_blood_cell_count = count_wbc(image_path)
    red_blood_cell_count = all_cells_count - white_blood_cell_count

    has_leukemia = None

    if float(red_blood_cell_count/white_blood_cell_count) > 13.6:
        has_leukemia = True
    else:
        has_leukemia = False

    return red_blood_cell_count, white_blood_cell_count, has_leukemia

def count_wbc(image_path):
    img = cv2.imread(image_path)
    img = brightness_up(img)

    img_grayscale = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    img_blur = cv2.medianBlur(img_grayscale, 7)

    ret, img_tr = cv2.threshold(img_blur, 170, 255, cv2.THRESH_BINARY)
    kernel = bb8.ones((3, 3))
    closing = cv2.morphologyEx(255 - img_tr, cv2.MORPH_CLOSE, kernel)
    img_for_erosion = closing.copy()

    #kernel1 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, ))

    img_eroded = cv2.erode(img_for_erosion, kernel, iterations=5)
    img_cont, contours, hierarchy = cv2.findContours(img_eroded, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    img_cont = img.copy()

    thresh = cv2.threshold(img_eroded, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]

    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (4, 4))
    close = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel, iterations=4)
    cnts = cv2.findContours(close, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[0] if len(cnts) == 2 else cnts[1]
    aa = cv2.fillPoly(close, cnts, [255, 255, 255])
    i = 0
    new_contours = []
    for contour in contours:
        if hierarchy[0, i, 3] == -1 and int(cv2.contourArea(contours[i])) > 110:
            new_contours.append(contour)
        i = i + 1

    cv2.drawContours(img_cont, new_contours, -1, (255, 0, 0), 1)
    white_blood_cells_count = len(new_contours)
    print(len(new_contours))

    return white_blood_cells_count

def count_all(img_path):
    img = cv2.imread(img_path)
    img = brightness_up(img)
    img_grayscale = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

    blur = cv2.bilateralFilter(img, 10, 75, 75)

    img_gs = cv2.cvtColor(blur, cv2.COLOR_RGB2GRAY)

    histoNorm = cv2.equalizeHist(img_gs)
    ret, img_tr = cv2.threshold(histoNorm, 100, 255,cv2.THRESH_BINARY)

    ret, thresh = cv2.threshold(img_tr, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    kernel = bb8.ones((3, 3), bb8.uint8)
    opening = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=1)

    dist_transform = cv2.distanceTransform(opening, cv2.DIST_L2, 3)
    ret, sure_fg = cv2.threshold(dist_transform, 0.05 * dist_transform.max(), 255, 0)

    sure_fg = bb8.uint8(sure_fg)
    sure_fg = 255 - sure_fg

    opening = cv2.morphologyEx(sure_fg, cv2.MORPH_OPEN, kernel)
    closing = cv2.morphologyEx(opening, cv2.MORPH_CLOSE, kernel)
    img_cont, contours, hierarchy = cv2.findContours(255-closing, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    img_final_cont = img.copy()

    i = 0
    new_contours = []
    for contour in contours:
        if hierarchy[0, i, 3] == -1:
            new_contours.append(contour)
        i = i + 1

    cv2.drawContours(img_final_cont, new_contours, -1, (255, 0, 0), 1)
    all_cells_count = len(new_contours)
    print(len(new_contours))
    return all_cells_count

def brightness_up(img):

    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)

    lim = 255 - 30
    v[v > lim] = 255
    v[v <= lim] += 30

    final_hsv = cv2.merge((h, s, v))
    img = cv2.cvtColor(final_hsv, cv2.COLOR_HSV2BGR)

    return img


